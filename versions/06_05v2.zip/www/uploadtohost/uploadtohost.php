
<?php
$uploaddir = $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR.'images'.DIRECTORY_SEPARATOR;
$uploadfile = $uploaddir . hash('crc32',time()) . '.jpeg';

if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
    $out = "File is correct and was uploaded successfully.\n";
} else {
    $out = "It was error occurred. Text\n";
}

echo $out;

?>