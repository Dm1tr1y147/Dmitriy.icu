
<?php
$uploaddir = $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR.'stories'.DIRECTORY_SEPARATOR.'texts'.DIRECTORY_SEPARATOR;
$uploadfile = $uploaddir . hash('crc32',time()) . '.html';

if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
    $out = "File is correct and was uploaded successfully. Text\n";
} else {
    $out = "It was error occurred\n";
}

echo $out;

?>