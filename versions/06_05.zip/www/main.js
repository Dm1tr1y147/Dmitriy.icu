$(document).ready(function() {
    $("select").change(function() {
        switch ($("select").val()) {
            case "gallery":
                $.ajax({
                    url: "gallery/gallery.php",
                    type: "POST",
                    cache: false,
                    success: function(html) {
                        $("#display").html(html);

                        var lnk = document.createElement('link');
                        $(lnk).attr('rel', 'stylesheet');
                        $(lnk).attr('href', 'gallery/gallery.css');
                        document.head.appendChild(lnk);
                        $('link[href="stories/stories.css"]').each(function() {
                            $(this).remove();
                        });

                        $("img:not(:lt(" + 6 + "))").hide();
                            var $offset = $('h1').offset().top - ($(window).width() / 20);
                            $('html, body').animate({
                                scrollTop: $offset
                            }, 750);
                    }
                });
                break;
            case "stories":
                $.ajax({
                    url: "stories/stories.php",
                    type: "POST",
                    cache: false,
                    success: function(html) {
                        $("#display").html(html);
                        var lnk = document.createElement('link');
                        $(lnk).attr('rel', 'stylesheet');
                        $(lnk).attr('href', 'stories/stories.css');
                        document.head.appendChild(lnk);
                        $('link[href="gallery/gallery.css"]').each(function() {
                            $(this).remove();
                        });

                        $("li:not(:lt(" + 3 + "))").hide();
                        var $offset = $('h1').offset().top - ($(window).width() / 20);
                        $('html, body').animate({
                            scrollTop: $offset
                        }, 750);
                    }
                });
                break;
        }
    });
    $('#menu-toggle').click(function(){
  		$(this).toggleClass('open');
	});
});