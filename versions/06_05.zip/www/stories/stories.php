<ul>
    <?php 
        $directory = "texts";
        $allowed_types = array("html", "htm", "xhtml");
        $file_parts = array();
        $ext="";
        $i=0;
        $dir_handle = @opendir($directory) or die("error loading");
        while ($file = readdir($dir_handle)) {
            if($file == "." || $file == "..") continue;
                $file_parts = explode(".", $file);
            $ext = strtolower(array_pop($file_parts));
            if(in_array($ext, $allowed_types)) {
                echo '<li><details>' . file_get_contents($directory.'/'.$file) . '</details></li>';
            }
        }
        closedir($dir_handle);
    ?>
    <div id="mores" onClick="window.location='/stories'"></div>
</ul>