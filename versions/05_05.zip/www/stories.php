<ul>
    <?php 
        $directory = "./stories";
        $allowed_types = array("html", "htm", "xhtml");
        $file_parts = array();
        $ext="";
        $i=0;
        $dir_handle = @opendir($directory) or die("error loading");
        while ($file = readdir($dir_handle)) {
            if($file == "." || $file == "..") continue;
                $file_parts = explode(".", $file);
            $ext = strtolower(array_pop($file_parts));
            if(in_array($ext, $allowed_types)) {
                echo '<li>' . file_get_contents($directory.'/'.$file) . '</li>';
            }
        }
        closedir($dir_handle);
    ?>
</ul>
<a href="stories.php" id="show"></a>
