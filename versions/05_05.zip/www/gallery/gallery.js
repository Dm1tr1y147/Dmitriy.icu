$(function() {
    $.ajax({
        url: "gallery.php",
        type: "POST",
        cache: false,
        success: function(html){
            $("#display").html(html);
        }
    });
    
    $('#menu-toggle').click(function(){
  		$(this).toggleClass('open');
	});
});