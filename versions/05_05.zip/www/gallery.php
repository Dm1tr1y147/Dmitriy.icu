<?php
    $directory = "./images";
    $allowed_types = array("jpg", "png", "gif");
    $file_parts = array();
    $ext="";
    $title="";
    $dir_handle = @opendir($directory) or die("error loading");
    while ($file = readdir($dir_handle)) {
        if($file == "." || $file == "..") continue;
            $file_parts = explode(".", $file);
        $ext = strtolower(array_pop($file_parts));
        if(in_array($ext, $allowed_types)) {
            echo '<img src="'.$directory.'/'.$file.'" />';
        }
    }
    closedir($dir_handle);
?>
<a href="gallery.php" id="show"></a>